/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kidnetpredictionp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class Preprocessing1 extends javax.swing.JFrame {

    int item[] = new int[30];
    int fat[] = new int[30];//Main array

    public Preprocessing1() {
        initComponents();
        jButton1.setVisible(true);
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        String sql = "select * from hreg";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/heart", "root", "");
            Statement st = (Statement) con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            Vector col = new Vector();
            col.add("PatientNo");
                   col.add("PatientEmail");
                   col.add("Age");
                   col.add("Sex");
                   col.add("bp");
                   col.add("sg");
                   col.add("al");
                   col.add("su");
                   col.add("rbc");
                   col.add("pc");
                   col.add("htn");
                   col.add("sod");
                   col.add("pot");
                   col.add("pcv");
                   col.add("rc");
                   col.add("wc");
            Vector row = new Vector();
            while (rs.next()) {
                String bn=rs.getString("PatientNo");
                  String d=rs.getString("PatientEmail");
                  String rt=rs.getString("Age");
                  String pn=rs.getString("Sex");
                  String per=rs.getString("bp");
                 String cour=rs.getString("sg");
                 String u2=rs.getString("al");
                 String n=rs.getString("su");
                  String n1=rs.getString("rbc");
                  String n2=rs.getString("pc");
                 String n3=rs.getString("htn");
                 String n4=rs.getString("sod");
                 String n5=rs.getString("pot");          
                  String n6=rs.getString("pcv");
                 String n7=rs.getString("rc");
                 String n8=rs.getString("wc");
                model.addRow(new Object[]{
                    bn, d, pn, per, cour, u2, n, n1, n2, n3, n4, n5, n6, n7, n8});
                Vector s = new Vector();
                s.add(bn);
                s.add(d);
                s.add(rt);
                s.add(pn);
                s.add(per);
                s.add(cour);
                s.add(u2);
                s.add(n);
                s.add(n1);
                s.add(n2);
                s.add(n3);
                s.add(n4);
                s.add(n5);
                s.add(n6);
                s.add(n7);
                s.add(n8);

                row.add(s);
            }

            jTable1.setModel(new DefaultTableModel(row, col));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }
        preprocess();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Preprocessing", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14), new java.awt.Color(51, 0, 255))); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText(">>Next");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Preprocessing");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("SaveDB");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1131, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(308, 308, 308)
                .addComponent(jButton3)
                .addGap(120, 120, 120)
                .addComponent(jButton2)
                .addGap(146, 146, 146)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 388, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        try {
             
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            TableColumn col = new TableColumn(model.getColumnCount());
            jTable1.setModel(model);
            for (int i = 0; i < jTable1.getRowCount(); i++) {

                String p1 = (jTable1.getValueAt(i, 0) + "");
                String p2 = (jTable1.getValueAt(i, 1) + "");
                String p3 = (jTable1.getValueAt(i, 2) + "");
                String p4 = (jTable1.getValueAt(i, 3) + "");
                String n = (jTable1.getValueAt(i, 4) + "");
                String p6 = (jTable1.getValueAt(i, 5) + "");
                String p7 = (jTable1.getValueAt(i, 6) + "");
                String p8 = (jTable1.getValueAt(i, 7) + "");
                String p9 = (jTable1.getValueAt(i, 8) + "");
                String p10 = (jTable1.getValueAt(i, 9) + "");
                String p11 = (jTable1.getValueAt(i, 10) + "");
                String p12 = (jTable1.getValueAt(i, 11) + "");
                String p13 = (jTable1.getValueAt(i, 12) + "");
                String p14 = (jTable1.getValueAt(i, 13) + "");
                String p15 = (jTable1.getValueAt(i, 14) + "");
                String p16 = (jTable1.getValueAt(i, 15) + "");
                if (p1.isEmpty() || p2.isEmpty() || p3.isEmpty() || p4.isEmpty() ||n.isEmpty() || p6.isEmpty() || p7.isEmpty() || p8.isEmpty() || p9.isEmpty() || p10.isEmpty() || p11.isEmpty() || p12.isEmpty() || p13.isEmpty() || p14.isEmpty() || p15.isEmpty() || p16.isEmpty()) 
                    model.removeRow(i);
                
            }
            jButton1.setEnabled(true);
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try {

            int rows = jTable1.getRowCount();
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/heart", "root", "");
            conn.setAutoCommit(false);

            String queryco = "Insert into result(PatientNo,PatientEmail,Age,Sex,CP,Trestbps,Chol,fbs,restecg,thalach,Exang,oldpeak,slope,ca,thal,smoke) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(queryco);
            for (int row = 0; row < rows; row++) {
                String coitemname = (String) jTable1.getValueAt(row, 0);
                String cocateg = (String) jTable1.getValueAt(row, 1);
                String codesc = (String) jTable1.getValueAt(row, 2);
                String coloc = (String) jTable1.getValueAt(row, 3);
                String coitemtagno = (String) jTable1.getValueAt(row, 4);
                String cocateg1 = (String) jTable1.getValueAt(row, 5);
                String codesc1 = (String) jTable1.getValueAt(row, 6);
                String coloc1 = (String) jTable1.getValueAt(row, 7);
                String coitemtagno1 = (String) jTable1.getValueAt(row, 8);

                String codesc2 = (String) jTable1.getValueAt(row, 9);
                String coloc2 = (String) jTable1.getValueAt(row, 10);
                String coitemtagno2 = (String) jTable1.getValueAt(row, 11);
                String cocateg2 = (String) jTable1.getValueAt(row, 12);
                String codesc3 = (String) jTable1.getValueAt(row, 13);
                String coloc3 = (String) jTable1.getValueAt(row, 14);
                String coitemtagno3 = (String) jTable1.getValueAt(row, 15);
                pst.setString(1, coitemname);
                pst.setString(2, cocateg);
                pst.setString(3, codesc);
                pst.setString(4, coloc);
                pst.setString(5, coitemtagno);
                pst.setString(6, cocateg1);
                pst.setString(7, codesc1);
                pst.setString(8, coloc1);
                pst.setString(9, coitemtagno1);
                pst.setString(10, codesc2);
                pst.setString(11, coloc2);
                pst.setString(12, coitemtagno2);
                pst.setString(13, cocateg2);
                pst.setString(14, codesc3);
                pst.setString(15, coloc3);
                pst.setString(16, coitemtagno3);
                pst.addBatch();
            }
            pst.executeBatch();
            JOptionPane.showMessageDialog(null, "Data Saved Successfully");
            conn.commit();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        new SVMClassifier().setVisible(true);
    }//GEN-LAST:event_jButton1ActionPerformed
    public void getdata() {
        int i = 0;
        String s1, s2;
        DBC db = new DBC();
        try {
            String queryString = ("SELECT * FROM hreg");
            Statement stmt = db.con.createStatement();
            db.rs = stmt.executeQuery(queryString);
            while (db.rs.next()) {
                s1 = db.rs.getString("Age");
                s2 = db.rs.getString("Sex");
                item[i] = Integer.parseInt(s1.trim());
                fat[i] = Integer.parseInt(s2.trim());
                i++;
            } //end of while
        }//end of try
        catch (SQLException sqle) {
            System.out.println("Some SQL error occured.");
        }
        try {
            if (db.con != null) {
                db.con.close();
            }
            System.out.println("Connection to DB closed..Data Retrieved Successfully!");
        } catch (Exception e) {
        }

    }//end of function

    public void cluster() {
        int m1, m2, m3;
        int i;
        int d1 = 0;
        int d2 = 0;
        int d3 = 0;
        int a = 1;
        int b = 1;
        int c = 1;
        int c11[] = new int[20];
        int c12[] = new int[20];//Cluster 1
        int c21[] = new int[20];
        int c22[] = new int[20];//Cluster 2
        int c31[] = new int[20];
        int c32[] = new int[20];//Cluster 3

        c11[0] = item[0];
        c12[0] = fat[0]; //Randomly place one item in each cluster
        c21[0] = item[1];
        c22[0] = fat[1];
        c31[0] = item[2];
        c32[0] = fat[2];

        m1 = c12[0];
        m2 = c22[0];
        m3 = c32[0];//Initial Mean value of each cluster

        for (i = 3; i < 20; i++) {
            d1 = Math.abs(m1 - fat[i]);
            d2 = Math.abs(m2 - fat[i]);
            d3 = Math.abs(m3 - fat[i]);

            if (d1 <= d2 && d1 <= d3) {
                c11[a] = item[i];
                c12[a] = fat[i];
                m1 = (c12[a] + m1) / 2;
                a++;
            }

            if (d2 <= d1 && d2 <= d3) {
                c21[b] = item[i];
                c22[b] = fat[i];
                m2 = (c22[b] + m2) / 2;
                b++;
            }

            if (d3 <= d1 && d3 <= d2) {
                c31[c] = item[i];
                c32[c] = fat[i];
                m3 = (c32[c] + m3) / 2;
                c++;
            }

        }//end of for...

        System.out.println("\n Data is classified into 3 clusters as follows..");
        System.out.println("\nCluster 1");
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        TableColumn col = new TableColumn(model.getColumnCount());
        model.addColumn("Cluster");
        System.out.println("----------");

        System.out.println("\nItem Fat\n");
        for (i = 0; i < 10; i++) {
            if (c12[i] == 0) {
                break;
            }
            System.out.print(c11[i]);

            System.out.print(" ");
            System.out.print(c12[i]);
            System.out.println("");
            model.setValueAt("C->1", i, 16);
        }

        System.out.println("\nCluster 2");
        System.out.println("----------");
        model.setValueAt("C->2", i, 16);
        System.out.println("\nItem Fat\n");
        for (i = 0; i < 10; i++) {
            if (c22[i] == 0) {
                break;
            }
            System.out.print(c21[i]);
            System.out.print(" ");
            System.out.print(c22[i]);
            System.out.println("");
        }

        System.out.println("\nCluster 3");
        System.out.println("----------");
        model.setValueAt("C->3", i, 16);
        System.out.println("\nItem Fat\n");
        for (i = 0; i < 10; i++) {
            if (c32[i] == 0) {
                break;
            }
            System.out.print(c31[i]);
            System.out.print(" ");
            System.out.print(c32[i]);
            System.out.println("");
        }

    }

    void preprocess() {
        try {
            //  SaveDB();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            TableColumn col = new TableColumn(model.getColumnCount());
            jTable1.setModel(model);
            for (int i = 0; i < jTable1.getRowCount(); i++) {

                String p1 = (jTable1.getValueAt(i, 0) + "");
                String p2 = (jTable1.getValueAt(i, 1) + "");
                String p3 = (jTable1.getValueAt(i, 2) + "");
                String p4 = (jTable1.getValueAt(i, 3) + "");
                String p5 = (jTable1.getValueAt(i, 4) + "");
                String p6 = (jTable1.getValueAt(i, 5) + "");
                String p7 = (jTable1.getValueAt(i, 6) + "");
                String p8 = (jTable1.getValueAt(i, 7) + "");
                String p9 = (jTable1.getValueAt(i, 8) + "");
                String p10 = (jTable1.getValueAt(i, 9) + "");
                String p11 = (jTable1.getValueAt(i, 10) + "");
                String p12 = (jTable1.getValueAt(i, 11) + "");
                String p13 = (jTable1.getValueAt(i, 12) + "");
                String p14 = (jTable1.getValueAt(i, 13) + "");
                String p15 = (jTable1.getValueAt(i, 14) + "");
                String p16 = (jTable1.getValueAt(i, 15) + "");
                if (p1.isEmpty() || p2.isEmpty() || p3.isEmpty() || p4.isEmpty() || p5.isEmpty() || p6.isEmpty() || p7.isEmpty() || p8.isEmpty() || p9.isEmpty() || p10.isEmpty() || p11.isEmpty() || p12.isEmpty() || p13.isEmpty() || p14.isEmpty() || p15.isEmpty() || p16.isEmpty()) {
                    model.removeRow(i);
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Preprocessing1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Preprocessing1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Preprocessing1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Preprocessing1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Preprocessing1().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables

}
