/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kidnetpredictionp;



import java.sql.*;
import java.lang.*;

class Kmeans
{
public Kmeans()
{ }
int item[]=new int[30];int fat[]=new int[30];//Main array
//Connection con=null;
//ResultSet rs=null;
DBC db=new DBC();
public void getdata()
{
int i=0;
String s1,s2;
try
{
    

System.out.println("Database connection established");
}//end of try

catch (Exception sqle)
{System.out.println("Unable to load driver...");}
try
{
String queryString=("SELECT * FROM hreg");
 db.st=db.con.createStatement();
db.rs=db.st.executeQuery(queryString);
while (db.rs.next())
{
s1=db.rs.getString("Age");
s2=db.rs.getString("Sex");
item[i]=Integer.parseInt(s1.trim());
fat[i]=Integer.parseInt(s2.trim());
i++;
} //end of while
}//end of try
catch (SQLException sqle)
{System.out.println("Some SQL error occured.");}
try
{if(db.con!=null)
{db.con.close();}
System.out.println("Connection to DB closed..Data Retrieved Successfully!");}
catch(Exception e)
{}


}//end of function

public void cluster()
{int m1,m2,m3;int i;int d1=0;int d2=0;int d3=0;int a=1;int b=1;int c=1;
int c11[]=new int[20];int c12[]=new int[20];//Cluster 1
int c21[]=new int[20];int c22[]=new int[20];//Cluster 2
int c31[]=new int[20];int c32[]=new int[20];//Cluster 3

c11[0]=item[0];c12[0]=fat[0]; //Randomly place one item in each cluster
c21[0]=item[1];c22[0]=fat[1];
c31[0]=item[2];c32[0]=fat[2];

m1=c12[0];m2=c22[0];m3=c32[0];//Initial Mean value of each cluster

for(i=3;i<20;i++)
{
d1=Math.abs(m1-fat[i]);
d2=Math.abs(m2-fat[i]);
d3=Math.abs(m3-fat[i]);

if(d1<=d2 && d1<=d3)
{c11[a]=item[i];
c12[a]=fat[i];
m1=(c12[a]+m1)/2;
a++;}

if(d2<=d1 && d2<=d3)
{c21[b]=item[i];
c22[b]=fat[i];
m2=(c22[b]+m2)/2;
b++;}


if(d3<=d1 && d3<=d2)
{c31[c]=item[i];
c32[c]=fat[i];
m3=(c32[c]+m3)/2;
c++;}


}//end of for...


System.out.println("\n Data is classified into 3 clusters as follows..");
System.out.println("\nCluster 1");
System.out.println("----------");

System.out.println("\nItem Fat\n");
for(i=0;i<10;i++)
{
if(c12[i]==0)
{break;}
System.out.print(c11[i]);
System.out.print(" ");
System.out.print(c12[i]);
System.out.println("");
}

System.out.println("\nCluster 2");
System.out.println("----------");
System.out.println("\nItem Fat\n");
for(i=0;i<10;i++)
{
if(c22[i]==0)
{break;}
System.out.print(c21[i]);
System.out.print(" ");
System.out.print(c22[i]);
System.out.println("");
}

System.out.println("\nCluster 3");
System.out.println("----------");
System.out.println("\nItem Fat\n");
for(i=0;i<10;i++)
{
if(c32[i]==0)
{break;}
System.out.print(c31[i]);
System.out.print(" ");
System.out.print(c32[i]);
System.out.println("");
}

}//end of function

public static void main(String args[])
{
Kmeans t=new Kmeans();
t.getdata();
t.cluster();
}

}
