package Kidnetpredictionp;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class DatasetView extends javax.swing.JFrame {

    static List<String[]> list;
    static String head[];
    static Vector<String> subj,sec;
    public DatasetView() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Dataset View");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText(">>Next");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });

        jButton3.setText("savedb");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(415, 415, 415)
                .addComponent(jLabel1)
                .addGap(102, 102, 102)
                .addComponent(jButton3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jButton3)
                    .addComponent(jLabel1))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 896, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 516, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            csvreader.CSVReader reader = new csvreader.CSVReader(new FileReader(Dataset.file));
            list = reader.readAll();
            reader.close();

            head = list.get(0);
            list.remove(0);
            jTable1.setModel(new DefaultTableModel(list.toArray(new String[][]{}), head));
            subj=new Vector<String>();
         /*   for(int i=0;i<head.length;i++)
            {
                if(head[i].equalsIgnoreCase("REG.NO")||head[i].equalsIgnoreCase("NAME")||head[i].equalsIgnoreCase("CLASS/SEC"))
                {
                }else{
                subj.add(head[i]);
                }
            }*/
            Set<String> set=new HashSet<String>();
           // int ix=2;
           /* for(int i=0;i<head.length;i++)
            {
            if(head[i].equalsIgnoreCase("CLASS/SEC"))
                ix=i;
            }*/
           /* for(int i=0;i<list.size();i++)
            {
            String ar[]=list.get(i);
            set.add(ar[ix].toUpperCase());
            }*/
            String ar[]=set.toArray(new String[]{});
            sec=new Vector<String>();
            for(int i=0;i<ar.length;i++)sec.add(ar[i]);
            System.out.println(sec);
            System.out.println(subj);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_formWindowOpened

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
//new ResultAnalysis_1().setVisible(true);
new ViewKidneyData().setVisible(true);
//this.setVisible(false);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        try{

            int rows=jTable1.getRowCount();
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/heart","root","");
            conn.setAutoCommit(false);

            String queryco = "Insert into hreg(PatientNo,PatientEmail,Age,Sex,bp,sg,al,su,rbc,pc,htn,sod,pot,pcv,rc,wc) values (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(queryco);
            for(int row = 0; row<rows; row++)
            {
                String coitemname = (String)jTable1.getValueAt(row, 0);
                String cocateg = (String)jTable1.getValueAt(row, 1);
                String codesc = (String)jTable1.getValueAt(row, 2);
                String coloc = (String)jTable1.getValueAt(row, 3);
                String coitemtagno = (String)jTable1.getValueAt(row, 4);
                String cocateg1 = (String)jTable1.getValueAt(row, 5);
                String codesc1 = (String)jTable1.getValueAt(row, 6);
                String coloc1 = (String)jTable1.getValueAt(row, 7);
                String coitemtagno1 = (String)jTable1.getValueAt(row, 8);

                String codesc2 = (String)jTable1.getValueAt(row, 9);
                String coloc2 = (String)jTable1.getValueAt(row, 10);
                String coitemtagno2 = (String)jTable1.getValueAt(row, 11);
                String cocateg2 = (String)jTable1.getValueAt(row, 12);
                String codesc3 = (String)jTable1.getValueAt(row, 13);
                String coloc3 = (String)jTable1.getValueAt(row, 14);
                String coitemtagno3 = (String)jTable1.getValueAt(row, 15);
                pst.setString(1, coitemname);
                pst.setString(2, cocateg);
                pst.setString(3, codesc);
                pst.setString(4, coloc);
                pst.setString(5, coitemtagno);
                pst.setString(6, cocateg1);
                pst.setString(7, codesc1);
                pst.setString(8, coloc1);
                pst.setString(9, coitemtagno1);
                pst.setString(10, codesc2);
                pst.setString(11, coloc2);
                pst.setString(12, coitemtagno2);
                pst.setString(13, cocateg2);
                pst.setString(14, codesc3);
                pst.setString(15, coloc3);
                pst.setString(16, coitemtagno3);
                pst.addBatch();
            }
            pst.executeBatch();
            JOptionPane.showMessageDialog(null, "Data Saved Successfully");
            
            conn.commit();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(this,e.getMessage());
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DatasetView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
