/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kidnetpredictionp;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;


public class SVMClassifier extends javax.swing.JFrame {

    public SVMClassifier() {
        initComponents();
        jButton3.setEnabled(true);
        
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Classification", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Times New Roman", 1, 14), new java.awt.Color(0, 0, 255))); // NOI18N

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jButton1.setText("SVM-Classifier");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton3.setText(">>Next");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton2.setText(">>Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1600, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(118, 118, 118)
                .addComponent(jButton1)
                .addGap(165, 165, 165)
                .addComponent(jButton3)
                .addGap(575, 575, 575))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton3)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 454, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
   
        SVMClassifier();
        jButton3.setEnabled(true);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
     
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();

        String sql = "select * from hreg";

        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/heart", "root", "");
            Statement st = (Statement) con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            Vector col = new Vector();
            col.add("PatientNo");
                   col.add("PatientEmail");
                   col.add("Age");
                   col.add("Sex");
                   col.add("bp");
                   col.add("sg");
                   col.add("al");
                   col.add("su");
                   col.add("rbc");
                   col.add("pc");
                   col.add("htn");
                   col.add("sod");
                   col.add("pot");
                   col.add("pcv");
                   col.add("rc");
                   col.add("wc");
            Vector row = new Vector();
            while (rs.next()) {
                String bn=rs.getString("PatientNo");
                  String d=rs.getString("PatientEmail");
                  String rt=rs.getString("Age");
                  String pn=rs.getString("Sex");
                  String per=rs.getString("bp");
                 String cour=rs.getString("sg");
                 String u2=rs.getString("al");
                 String n=rs.getString("su");
                  String n1=rs.getString("rbc");
                  String n2=rs.getString("pc");
                 String n3=rs.getString("htn");
                 String n4=rs.getString("sod");
                 String n5=rs.getString("pot");          
                  String n6=rs.getString("pcv");
                 String n7=rs.getString("rc");
                 String n8=rs.getString("wc");
                model.addRow(new Object[]{
                    bn, d, pn, per, cour, u2, n, n1, n2, n3, n4, n5, n6, n7, n8});
                Vector s = new Vector();
                s.add(bn);
                s.add(d);
                s.add(rt);
                s.add(pn);
                s.add(per);
                s.add(cour);
                s.add(u2);
                s.add(n);
                s.add(n1);
                s.add(n2);
                s.add(n3);
                s.add(n4);
                s.add(n5);
                s.add(n6);
                s.add(n7);
                s.add(n8);

                row.add(s);
            }

            jTable1.setModel(new DefaultTableModel(row, col));
            prre();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(rootPane, e.getMessage());
        }


    }//GEN-LAST:event_formWindowOpened

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        new ResultPrediction().setVisible(true);
        //new Clustering1().setVisible(true);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        new Preprocessing1().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed
    void SVMClassifier() {
        try {
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            TableColumn col = new TableColumn(model.getColumnCount());
            model.addColumn("Kidney Prediction");
            jTable1.setModel(model);
            for (int i = 0; i < jTable1.getRowCount(); i++) {
                int bp = Integer.parseInt(jTable1.getValueAt(i, 4) + "");
                //int sg = Integer.parseInt(jTable1.getValueAt(i, 5) + "");
                int al = Integer.parseInt(jTable1.getValueAt(i, 6) + "");
                int su = Integer.parseInt(jTable1.getValueAt(i, 7) + "");
                int CP1 = Integer.parseInt(jTable1.getValueAt(i, 10) + "");
                //int CPP = Integer.parseInt(jTable1.getValueAt(i, 4) + "");
                //int CP = Integer.parseInt(jTable1.getValueAt(i, 5) + "");
                //int CP1 = Integer.parseInt(jTable1.getValueAt(i, 10) + "");
                //int CP2 = Integer.parseInt(jTable1.getValueAt(i, 7) + "");
                //int CP3 = Integer.parseInt(jTable1.getValueAt(i, 8) + "");//
                //int CP4=Integer.parseInt(rt.getValueAt(i, 11)+"");
                if (bp == 80 && bp >= 60 && al == 0 && su == 0 && CP1 == 0) {
                    System.out.println("not Kidney Disease");
                    model.setValueAt("0", i, 16);
                } else {
                    System.out.println("Kidney Disease");
                    model.setValueAt("1", i, 16);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
       }
       void prre()
      {
      try {
            //  SaveDB();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            TableColumn col = new TableColumn(model.getColumnCount());
            jTable1.setModel(model);
            for (int i = 0; i < jTable1.getRowCount(); i++) {

                String p1 = (jTable1.getValueAt(i, 0) + "");
                String p2 = (jTable1.getValueAt(i, 1) + "");
                String p3 = (jTable1.getValueAt(i, 2) + "");
                String p4 = (jTable1.getValueAt(i, 3) + "");
                String p5 = (jTable1.getValueAt(i, 4) + "");
                String p6 = (jTable1.getValueAt(i, 5) + "");
                String p7 = (jTable1.getValueAt(i, 6) + "");
                String p8 = (jTable1.getValueAt(i, 7) + "");
                String p9 = (jTable1.getValueAt(i, 8) + "");
                String p10 = (jTable1.getValueAt(i, 9) + "");
                String p11 = (jTable1.getValueAt(i, 10) + "");
                String p12 = (jTable1.getValueAt(i, 11) + "");
                String p13 = (jTable1.getValueAt(i, 12) + "");
                String p14 = (jTable1.getValueAt(i, 13) + "");
                String p15 = (jTable1.getValueAt(i, 14) + "");
                String p16 = (jTable1.getValueAt(i, 15) + "");
                if (p1.isEmpty() || p2.isEmpty() || p3.isEmpty() || p4.isEmpty() || p5.isEmpty() || p6.isEmpty() || p7.isEmpty() || p8.isEmpty() || p9.isEmpty() || p10.isEmpty() || p11.isEmpty() || p12.isEmpty() || p13.isEmpty() || p14.isEmpty() || p15.isEmpty() || p16.isEmpty()) {
                    model.removeRow(i);
                }
            }
            prre1();
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
     }
      void prre1()
      {
      try {
            //  SaveDB();
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            TableColumn col = new TableColumn(model.getColumnCount());
            jTable1.setModel(model);
            for (int i = 0; i < jTable1.getRowCount(); i++) {

                String p1 = (jTable1.getValueAt(i, 0) + "");
                String p2 = (jTable1.getValueAt(i, 1) + "");
                String p3 = (jTable1.getValueAt(i, 2) + "");
                String p4 = (jTable1.getValueAt(i, 3) + "");
                String p5 = (jTable1.getValueAt(i, 4) + "");
                String p6 = (jTable1.getValueAt(i, 5) + "");
                String p7 = (jTable1.getValueAt(i, 6) + "");
                String p8 = (jTable1.getValueAt(i, 7) + "");
                String p9 = (jTable1.getValueAt(i, 8) + "");
                String p10 = (jTable1.getValueAt(i, 9) + "");
                String p11 = (jTable1.getValueAt(i, 10) + "");
                String p12 = (jTable1.getValueAt(i, 11) + "");
                String p13 = (jTable1.getValueAt(i, 12) + "");
                String p14 = (jTable1.getValueAt(i, 13) + "");
                String p15 = (jTable1.getValueAt(i, 14) + "");
                String p16 = (jTable1.getValueAt(i, 15) + "");
                if (p1.isEmpty() || p2.isEmpty() || p3.isEmpty() || p4.isEmpty() || p5.isEmpty() || p6.isEmpty() || p7.isEmpty() || p8.isEmpty() || p9.isEmpty() || p10.isEmpty() || p11.isEmpty() || p12.isEmpty() || p13.isEmpty() || p14.isEmpty() || p15.isEmpty() || p16.isEmpty()) {
                    model.removeRow(i);
                }
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
        }
}

    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SVMClassifier().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
