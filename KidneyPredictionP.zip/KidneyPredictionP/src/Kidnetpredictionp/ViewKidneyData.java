/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kidnetpredictionp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class ViewKidneyData extends javax.swing.JFrame {


    public ViewKidneyData() {
        initComponents();
        DefaultTableModel model=(DefaultTableModel)jTable1.getModel();
              
        String sql="select * from hreg";
     
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
             Connection con=(Connection)DriverManager.getConnection("jdbc:mysql://localhost:3306/heart","root","");
              Statement st= (Statement) con.createStatement();
              ResultSet rs=st.executeQuery(sql);
 
                   Vector col=new Vector();
                   col.add("PatientNo");
                   col.add("PatientEmail");
                   col.add("Age");
                   col.add("Sex");
                   col.add("bp");
                   col.add("sg");
                   col.add("al");
                   col.add("su");
                   col.add("rbc");
                   col.add("pc");
                   col.add("htn");
                   col.add("sod");
                   col.add("pot");
                   col.add("pcv");
                   col.add("rc");
                   col.add("wc");
                   Vector row=new Vector();
              while(rs.next())
              {
                  String bn=rs.getString("PatientNo");
                  String d=rs.getString("PatientEmail");
                  String rt=rs.getString("Age");
                  String pn=rs.getString("Sex");
                  String per=rs.getString("bp");
                 String cour=rs.getString("sg");
                 String u2=rs.getString("al");
                 String n=rs.getString("su");
                  String n1=rs.getString("rbc");
                  String n2=rs.getString("pc");
                 String n3=rs.getString("htn");
                 String n4=rs.getString("sod");
                 String n5=rs.getString("pot");          
                  String n6=rs.getString("pcv");
                 String n7=rs.getString("rc");
                 String n8=rs.getString("wc");
                   model.addRow(new Object []{
               bn,d,pn,per,cour,u2,n,n1,n2,n3,n4,n5,n6,n7,n8});
                   Vector s=new Vector();
                   s.add(bn);
                   s.add(d);
                   s.add(rt);
                   s.add(pn);
                   s.add(per);
                   s.add(cour);
                   s.add(u2);
                   s.add(n);
                   s.add(n1);
                   s.add(n2);
                   s.add(n3);
                   s.add(n4);
                   s.add(n5);
                   s.add(n6);
                   s.add(n7);
                   s.add(n8);          
                   row.add(s);
            }

jTable1.setModel(new DefaultTableModel(row,col));
        }
        catch(Exception e)
        {
           JOptionPane.showMessageDialog(rootPane, e.getMessage());
    }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jButton2 = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton2.setText("<<Home");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton1.setText(">>Pre-Processing");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(156, 156, 156)
                .addComponent(jButton2)
                .addGap(258, 258, 258)
                .addComponent(jButton1)
                .addContainerGap(575, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton2)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 324, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        try
        {
            new Preprocessing1().setVisible(true);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
         new Home().setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ViewKidneyData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ViewKidneyData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ViewKidneyData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ViewKidneyData.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewKidneyData().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
