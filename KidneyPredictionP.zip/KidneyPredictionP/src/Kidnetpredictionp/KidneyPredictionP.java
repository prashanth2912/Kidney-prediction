/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Kidnetpredictionp;

import javax.swing.UIManager;

/**
 *
 * @author smallko
 */
public class KidneyPredictionP {

   
    public static void main(String[] args) {
         try {
                  
UIManager.setLookAndFeel("com.jtattoo.plaf.luna.LunaLookAndFeel");

            new Home().setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
