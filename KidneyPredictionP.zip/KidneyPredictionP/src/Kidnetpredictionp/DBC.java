package Kidnetpredictionp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public class DBC {

    public Connection con;
    public Statement st;
    public ResultSet rs;
    public ResultSetMetaData rsm;
    public String dbname = "heart";
    public String url = "jdbc:mysql://localhost:3306/";

    public DBC() {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection(url + dbname, "root", "");
            st = con.createStatement();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public DBC(String dbn) {
        try {
            dbname = dbn;
            con = DriverManager.getConnection(url + dbname, "root", "");
            st = con.createStatement();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public int execUpdate(String qry) {
        int r = 0;
        try {
            r = st.executeUpdate(qry);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return r;
    }

    public ResultSet execQuery(String qry) {
        rs = null;
        try {
            rs = st.executeQuery(qry);
            rsm = rs.getMetaData();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return rs;
    }
}
